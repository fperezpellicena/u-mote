/*****************************************************************************
* Product: QDPP example, DOS, Large model, Open Watcom compiler
* Last Updated for Version: 4.2.00
* Date of the Last Update:  Jul 14, 2011
*
*                    Q u a n t u m     L e a P s
*                    ---------------------------
*                    innovating embedded systems
*
* Copyright (C) 2002-2011 Quantum Leaps, LLC. All rights reserved.
*
* This software may be distributed and modified under the terms of the GNU
* General Public License version 2 (GPL) as published by the Free Software
* Foundation and appearing in the file GPL.TXT included in the packaging of
* this file. Please note that GPL Section 2[b] requires that all works based
* on this software must also be made publicly available under the terms of
* the GPL ("Copyleft").
*
* Alternatively, this software may be distributed and modified under the
* terms of Quantum Leaps commercial licenses, which expressly supersede
* the GPL and are specifically designed for licensees interested in
* retaining the proprietary status of their code.
*
* Contact information:
* Quantum Leaps Web site:  http://www.quantum-leaps.com
* e-mail:                  info@quantum-leaps.com
*****************************************************************************/
#include "qp_port.h"
#include "dpp.h"
#include "bsp.h"
#include "video.h"

#include <dos.h>                       /* for _dos_setvect()/_dos_getvect() */
#include <conio.h>                                      /* for inp()/outp() */
#include <stdlib.h>                                          /* for _exit() */

Q_DEFINE_THIS_FILE

/* Local objects -----------------------------------------------------------*/
static void interrupt (*l_dosTickISR)(void);

static uint32_t l_delay = 0UL; /* limit for the loop counter in busyDelay() */

#ifdef Q_SPY
    static uint16_t l_uart_base;        /* QS data uplink UART base address */
    static QSTimeCtr l_tickTime;                 /* keeps timetsamp at tick */
    static uint8_t   l_tickHook;
    static uint8_t   l_kbdTask;

    #define UART_16550_TXFIFO_DEPTH 16

    enum AppRecords {                 /* application-specific trace records */
        PHILO_STAT = QS_USER
    };
#endif

#define TMR_VECTOR         0x08
#define DOS_CHAIN_VECTOR   0x81

/*..........................................................................*/
void ucosTask(void *pdata) {
    (void)pdata;       /* avoid the compiler warning about unused parameter */

    QF_onStartup();    /* start interrupts including the clock tick, NOTE01 */

    for (;;) {

        OSTimeDly(OS_TICKS_PER_SEC/10);                 /* sleep for 1/10 s */

        if (kbhit()) {                           /* poll for a new keypress */
            uint8_t key = (uint8_t)getch();
            if (key == 0x1B) {                      /* is this the ESC key? */
                QF_PUBLISH(Q_NEW(QEvent, TERMINATE_SIG), &l_kbdTask);
            }
            else {                                     /* other key pressed */
                Video_printNumAt(30, 13 + N_PHILO, VIDEO_FGND_YELLOW, key);
            }
        }
    }
}
/*..........................................................................*/
void BSP_init(int argc, char *argv[]) {
    char const *com = "COM1";
    uint8_t n;

    if (argc > 1) {
        l_delay = atol(argv[1]);    /* set the delay counter for busy delay */
    }
    if (argc > 2) {
        com = argv[2];
        (void)com;           /* avoid compiler warning if Q_SPY not defined */
    }
    if (!QS_INIT(com)) {                                   /* initialize QS */
        Q_ERROR();
    }

    QS_OBJ_DICTIONARY(&l_tickHook);
    QS_OBJ_DICTIONARY(&l_kbdTask);

    Video_clearScreen(VIDEO_BGND_BLACK);
    Video_clearRect( 0,  0, 80,  7, VIDEO_BGND_LIGHT_GRAY);
    Video_clearRect( 0, 11, 80, 12, VIDEO_BGND_LIGHT_GRAY);
    Video_clearRect( 0, 12, 41, 23, VIDEO_BGND_BLUE);
    Video_clearRect(41, 12, 80, 23, VIDEO_BGND_RED);
    Video_clearRect( 0, 23, 80, 24, VIDEO_BGND_LIGHT_GRAY);

    n = VIDEO_FGND_BLUE;
    Video_printStrAt(10, 0, n, "  __");
    Video_printStrAt(10, 1, n, " /  |      _   _ -|-     _ _");
    Video_printStrAt(10, 2, n, " \\__| | |  _\\ | \\ | | | | \\ \\");
    Video_printStrAt(10, 3, n, "    | \\_/ |_| | | | \\_| | | |");
    Video_printStrAt(10, 4, n, "    |");
    n = VIDEO_FGND_RED;
    Video_printStrAt(43, 0, n, "    _       __ ");
    Video_printStrAt(43, 1, n, "|  /_\\     |  \\  TM");
    Video_printStrAt(43, 2, n, "|  \\_   _  |__/ _");
    Video_printStrAt(43, 3, n, "|       _\\ |   |_");
    Video_printStrAt(43, 4, n, "|___   |_| |    _|");
    Video_printStrAt(10, 5, VIDEO_FGND_BLUE,
                     "_____________________________________________________");
    Video_printStrAt(10, 6, VIDEO_FGND_RED,
                     "i n n o v a t i n g   e m b e d d e d   s y s t e m s");
    Video_printStrAt(18,  7, VIDEO_FGND_WHITE,
                     "Dining Philosophers Example");
    Video_printStrAt(18,  8, VIDEO_FGND_WHITE, "QEP/C");
    Video_printStrAt(28,  8, VIDEO_FGND_YELLOW, QEP_getVersion());
    Video_printStrAt(18,  9, VIDEO_FGND_WHITE, "QF/C");
    Video_printStrAt(28,  9, VIDEO_FGND_YELLOW, QF_getVersion());
    Video_printStrAt(18, 10, VIDEO_FGND_WHITE, "uC/OS-II");

    /* uC/OS-II version is returned as an integer value multiplied by 100 */
    Video_printNumAt(29, 10, VIDEO_FGND_YELLOW, OSVersion()%100);
    Video_printStrAt(28, 10, VIDEO_FGND_YELLOW, "2.");

    Video_printStrAt( 1, 11, VIDEO_FGND_BLUE,
                     "Active Object   State        Data");

    for (n = 0; n < N_PHILO; ++n) {
        Video_printStrAt( 1, 12 + n, VIDEO_FGND_WHITE, "Philosopher");
        Video_printNumAt(12, 12 + n, VIDEO_FGND_WHITE, n + 1);
    }
    Video_printStrAt( 1, 12 + N_PHILO, VIDEO_FGND_WHITE,  "Table");
    Video_printStrAt(17, 12 + N_PHILO, VIDEO_FGND_YELLOW, "serving");
    Video_printStrAt( 1, 12 + N_PHILO + 1, VIDEO_FGND_WHITE,  "ucosTask");
    Video_printStrAt(17, 12 + N_PHILO + 1, VIDEO_FGND_YELLOW, "active");

    Video_printStrAt(4, 23, VIDEO_FGND_BLUE,
         "* Copyright (c) Quantum Leaps, LLC * www.quantum-leaps.com *");
    Video_printStrAt(28, 24, VIDEO_FGND_LIGHT_RED,
         "<< Press Esc to quit >>");
}
/*..........................................................................*/
void BSP_displyPhilStat(uint8_t n, char const *stat) {
    Video_printStrAt(17, 12 + n, VIDEO_FGND_YELLOW, stat);

    QS_BEGIN(PHILO_STAT, AO_Philo[n])  /* application-specific record begin */
        QS_U8(1, n);                                  /* Philosopher number */
        QS_STR(stat);                                 /* Philosopher status */
    QS_END()
}
/*..........................................................................*/
void BSP_busyDelay(void) {
    uint32_t volatile i = l_delay;
    while (i-- > 0UL) {                                   /* busy-wait loop */
    }
}
/*..........................................................................*/
void QF_onStartup(void) {
                                      /* divisor for the 8254 timer/counter */
    uint16_t count = (uint16_t)(((1193180 * 2) / OS_TICKS_PER_SEC + 1) >> 1);
    QF_INT_KEY_TYPE int_key;

    QF_INT_LOCK(int_key);

    l_dosTickISR  = _dos_getvect(TMR_VECTOR);
             /* install the original DOS timer vector for uC/OS-II to chain */
    _dos_setvect(DOS_CHAIN_VECTOR, l_dosTickISR);
                                        /* install the uC/OS-II tick vector */
    _dos_setvect(TMR_VECTOR, (void interrupt (*)(void))&OSTickISR);

    outp(0x43, 0x36);                 /* use mode-3 for timer 0 in the 8254 */
    outp(0x40, count & 0xFF);                  /* load low  byte of timer 0 */
    outp(0x40, (count >> 8) & 0xFF);           /* load high byte of timer 0 */
    QF_INT_UNLOCK(int_key);
}
/*..........................................................................*/
void QF_onCleanup(void) {
    QF_INT_KEY_TYPE int_key;
    QF_INT_LOCK(int_key);
    outp(0x43, 0x36);                 /* use mode-3 for timer 0 in the 8254 */
    outp(0x40, 0);                             /* load low  byte of timer 0 */
    outp(0x40, 0);                             /* load high byte of timer 0 */
    _dos_setvect(TMR_VECTOR, l_dosTickISR);       /* restore the DOS vector */
    QF_INT_UNLOCK(int_key);

    QS_EXIT();                            /* cleanp the QS software tracing */
    _exit(0);                                                /* exit to DOS */
}
/*..........................................................................*/
void OSTimeTickHook(void) {
    QF_TICK(&l_tickHook);
}
/*..........................................................................*/
void OSTaskIdleHook(void) {
#ifdef Q_SPY
    if ((inp(l_uart_base + 5) & (1 << 5)) != 0) {         /* Tx FIFO empty? */
        uint16_t fifo = UART_16550_TXFIFO_DEPTH;     /* 16550 Tx FIFO depth */
        uint8_t const *block;
        QF_INT_KEY_TYPE int_key;
        QF_INT_LOCK(int_key);
        block = QS_getBlock(&fifo);    /* try to get next block to transmit */
        QF_INT_UNLOCK(int_key);
        while (fifo-- != 0) {                    /* any bytes in the block? */
            outp(l_uart_base + 0, *block++);
        }
    }
#endif
}
/*..........................................................................*/
void Q_onAssert(char const Q_ROM * const Q_ROM_VAR file, int line) {
    Video_clearRect(0, 24, 80, 25, VIDEO_BGND_RED);
    Video_printStrAt(0, 24, VIDEO_FGND_WHITE, "ASSERTION FAILED in file:");
    Video_printStrAt(26, 24, VIDEO_FGND_YELLOW, file);
    Video_printStrAt(57, 24, VIDEO_FGND_WHITE, "line:");
    Video_printNumAt(62, 24, VIDEO_FGND_YELLOW, line);

    QF_stop();
}

/*--------------------------------------------------------------------------*/
#ifdef Q_SPY                                         /* define QS callbacks */

/*..........................................................................*/
static uint8_t UART_config(char const *comName, uint32_t baud) {
    switch (comName[3]) {          /* Set the base address of the COMx port */
        case '1': l_uart_base = (uint16_t)0x03F8; break;            /* COM1 */
        case '2': l_uart_base = (uint16_t)0x02F8; break;            /* COM2 */
        case '3': l_uart_base = (uint16_t)0x03E8; break;            /* COM3 */
        case '4': l_uart_base = (uint16_t)0x02E8; break;            /* COM4 */
        default: return (uint8_t)0;        /* COM port out of range failure */
    }
    baud = (uint16_t)(115200UL / baud);            /* divisor for baud rate */
    outp(l_uart_base + 3, (1 << 7));       /* Set divisor access bit (DLAB) */
    outp(l_uart_base + 0, (uint8_t)baud);                   /* Load divisor */
    outp(l_uart_base + 1, (uint8_t)(baud >> 8));
    outp(l_uart_base + 3, (1 << 1) | (1 << 0));    /* LCR:8-bits,no p,1stop */
    outp(l_uart_base + 4, (1 << 3) | (1 << 1) | (1 << 0));  /* DTR,RTS,Out2 */
    outp(l_uart_base + 1, 0);        /* Put UART into the polling FIFO mode */
    outp(l_uart_base + 2, (1 << 2) | (1 << 0));    /* FCR: enable, TX clear */

    return (uint8_t)1;                                           /* success */
}
/*..........................................................................*/
uint8_t QS_onStartup(void const *arg) {
    static uint8_t qsBuf[1*1024];                 /* buffer for Quantum Spy */
    QS_initBuf(qsBuf, sizeof(qsBuf));
    return UART_config((char const *)arg, 115200UL);
}
/*..........................................................................*/
void QS_onCleanup(void) {
}
/*..........................................................................*/
QSTimeCtr QS_onGetTime(void) {            /* invoked with interrupts locked */
    static uint32_t l_lastTime;
    uint32_t now;
    uint16_t count16;                         /* 16-bit count from the 8254 */

    outp(0x43, 0);                      /* latch the 8254's counter-0 count */
    count16 = (uint16_t)inp(0x40);        /* read the low byte of counter-0 */
    count16 += ((uint16_t)inp(0x40) << 8);            /* add on the hi byte */

    now = l_tickTime + (0x10000 - count16);

    if (l_lastTime > now) {                 /* are we going "back" in time? */
        now += 0x10000;               /* assume that there was one rollover */
    }
    l_lastTime = now;

    return (QSTimeCtr)now;
}
/*..........................................................................*/
void QS_onFlush(void) {
    uint16_t fifo = UART_16550_TXFIFO_DEPTH;         /* 16550 Tx FIFO depth */
    uint8_t const *block;
    QF_INT_KEY_TYPE int_key;
    QF_INT_LOCK(int_key);
    while ((block = QS_getBlock(&fifo)) != (uint8_t *)0) {
        QF_INT_UNLOCK(int_key);
                                           /* busy-wait until TX FIFO empty */
        while ((inp(l_uart_base + 5) & (1 << 5)) == 0) {
        }

        while (fifo-- != 0) {                    /* any bytes in the block? */
            outp(l_uart_base + 0, *block++);
        }
        fifo = UART_16550_TXFIFO_DEPTH;      /* re-load 16550 Tx FIFO depth */
        QF_INT_LOCK(int_key);
    }
    QF_INT_UNLOCK(int_key);
}
#endif                                                             /* Q_SPY */
/*--------------------------------------------------------------------------*/
