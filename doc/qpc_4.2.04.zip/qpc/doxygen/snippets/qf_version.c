    printf("Quantum DPP\nQEP %s\nQF  %s, QF port %s\n"
           "Press ESC to quit...\n",
           QEP_getVersion(),
           QF_getVersion(), QF_getPortVersion());
